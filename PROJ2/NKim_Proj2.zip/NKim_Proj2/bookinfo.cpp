#include <iostream>
#include <iomanip>
using namespace std;
void printBookInfo();

int main() {
    printBookInfo();
}

void printBookInfo(){

    //printing book info
    cout << setw(30) << right << "Serendipity Booksellers\n" << setw(28) << "Book Information\n\n";
    cout << "ISBN:" << setw(30) << right << "" << endl; 
    cout << "Title:" << setw(29) << right << "" << endl;
    cout << "Author:" << setw(28) << right << "" << endl;
    cout << "Publisher:" << setw(25) << right << "" << endl;
    cout << "Date Added:" << setw(24) << right << "" << endl;
    cout << "Quantity:" << setw(26) << right << "" << endl;
    cout << "Wholesale Cost:" << setw(20) << right << "" << endl;
    cout << "Retail Price:" << setw(22) << right << "" << endl << endl;
}