#ifndef BOOKINFO_H
#define BOOKINFO_H

#include <iostream>
#include <iomanip>
using namespace std;

//prototypes
void bookInfo(string, string, string, string, string, int, double, double);

#endif