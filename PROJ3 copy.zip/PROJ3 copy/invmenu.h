#ifndef INV_H
#define INV_H

#include <iostream>
#include <iomanip>
using namespace std;

//prototypes
void invMenu();
void lookUpBook();
void addBook();
void editBook();
void deleteBook();

#endif