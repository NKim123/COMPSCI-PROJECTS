#ifndef STRUPR_H
#define STRUPR_H

#include <cctype>
#include <string>

void strUpper(char*);

#endif